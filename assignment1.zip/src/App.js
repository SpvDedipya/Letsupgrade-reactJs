import React from "react"
import "./style.css"
import Button from "./Button"

function App() {
    return (
        <div className="container">
            <h1>HELLO EVERYONE</h1>
            <h4>WELCOME TO REACT</h4>
        </div>
    )
}
export default App